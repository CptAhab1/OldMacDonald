public class NamedCow extends Cow{

    private String Name;
    public NamedCow(String cowName){
        Name = cowName;
    }

    public String getName(){ return Name;}
}
