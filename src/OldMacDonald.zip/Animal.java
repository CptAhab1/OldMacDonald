public interface Animal{
    public String getSound();
    public String getType();
}