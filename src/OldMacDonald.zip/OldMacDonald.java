public class OldMacDonald {
    public static void main(String[] args){
        /*Cow c = new Cow();
        System.out.println( c.getType() + " goes " + c.getSound() );

        Chick ch = new Chick();
        System.out.println(ch.getType() + " goes " + ch.getSound());
*/
        Farm farm = new Farm();
        farm.animalSounds();
    }
}


